package edu.unl.cse.sql;

import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.unl.cse.model.Album;

public class AlbumBean {

	public Album getDetailedAlbum(String albumTitle)
	{
		/*
		 * Query the database and get the album with the 
		 * specified ID, create an Album object with all
		 * details specified
		 */
		//TODO: implement this method
		Album a = new Album();
		return a;
	}
	
	public List<Album> getAlbums() {
		//TODO: implement this method
		return new ArrayList<Album>();
	}
	
	/**
	 * Before you test your Java App, you can
	 * test your method implementations using this main:
	 * @param args
	 */
	public static void main(String args[]) {
		
		System.out.println("Albums: ");
		AlbumBean ab = new AlbumBean();
		for(Album a : ab.getAlbums()) {
			System.out.println("\t"+a.getTitle()+" (id = "+a.getAlbumId()+")");
		}
		
		Album da = null; 
		try {
			da = ab.getAlbums().iterator().next();
		} catch (Exception e) {
			System.out.println("No albums returned in the list");
		}
		if(da != null) {
			System.out.println(da.getTitle()+" details: ");
			for(String trackTitle : da.getSongTitles()) {
				System.out.println("\t"+trackTitle);
			}
		}
	}
}
